#!/usr/bin/env python3
"""
edb2xml.py - Convert .edb / .sdb / .pdb / .E2E database files to XML.

The file type is detected from its contents, not its extension:

  - Heidelberg Engineering eye-scan files (HEYEX / Spectralis OCT:
    .sdb, .edb, .pdb, .E2E) become <heyex> XML with the records grouped by
    patient, study, series and slice. Add --images DIR to also save the
    scan images as PNG files. These files contain patient data.
  - Windows ESE databases (Windows.edb, SRUDB.dat, ntds.dit, secedit.sdb)
    become <database> / <table> / <row> XML.
  - Windows application compatibility databases (sysmain.sdb) become
    nested XML that mirrors the tag tree (DATABASE, EXE, LAYER, ...).

Requires Python 3.8+. Only Windows ESE databases need an extra package:
  pip install dissect.esedb

Usage:
  python edb2xml.py scan.sdb                        # writes scan.xml
  python edb2xml.py scan.sdb --images scan_images   # XML plus PNG images
  python edb2xml.py Windows.edb -o out.xml
  python edb2xml.py Windows.edb --list              # show tables and exit
  python edb2xml.py Windows.edb -t SystemIndex_Gthr --max-rows 1000

The Heidelberg format is undocumented; this reader follows the
reverse-engineered descriptions from the eyepy, OCT-Converter and LibE2E
projects. Record types it does not understand are written as raw bytes.

Files are opened read-only and the XML is streamed to disk.
"""

import argparse
import base64
import datetime
import re
import math
import struct
import sys
import uuid
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

try:
    from dissect.esedb import EseDB
except ImportError:  # only needed for ESE databases, not shim .sdb files
    EseDB = None

# Characters that are not allowed in XML 1.0 documents.
_INVALID_XML = re.compile(
    "[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]|[\ud800-\udfff]"
)


def clean(text):
    """Escape a string for XML, replacing characters XML cannot hold."""
    text = _INVALID_XML.sub(lambda m: "\\x%02x" % ord(m.group()), text)
    return escape(text)


def attr(text):
    """Quote a string for use as an XML attribute value."""
    return quoteattr(_INVALID_XML.sub("?", str(text)))


def type_name(column):
    """Readable JET column type, e.g. 'Long', 'LongText', 'DateTime'."""
    name = getattr(column.type, "name", None) or str(column.type)
    return name.replace("JET_coltyp", "").strip("._") or "Unknown"


def format_scalar(value, binary_mode):
    """Return (text, encoding) for a single non-list value."""
    if isinstance(value, (bytes, bytearray, memoryview)):
        data = bytes(value)
        if binary_mode == "base64":
            return base64.b64encode(data).decode("ascii"), "base64"
        return data.hex(), "hex"
    if isinstance(value, datetime.datetime):
        return value.isoformat(), None
    if isinstance(value, bool):
        return ("true" if value else "false"), None
    if isinstance(value, uuid.UUID):
        return str(value), None
    return clean(str(value)), None


def write_field(out, name, value, binary_mode, indent):
    """Write one <field> element. Multi-valued columns get <value> children."""
    if isinstance(value, (list, tuple)):
        out.write(f"{indent}<field name={attr(name)} multi=\"true\">\n")
        for item in value:
            if item is None:
                out.write(f"{indent}  <value null=\"true\"/>\n")
                continue
            text, enc = format_scalar(item, binary_mode)
            enc_attr = f" encoding=\"{enc}\"" if enc else ""
            out.write(f"{indent}  <value{enc_attr}>{text}</value>\n")
        out.write(f"{indent}</field>\n")
        return

    text, enc = format_scalar(value, binary_mode)
    enc_attr = f" encoding=\"{enc}\"" if enc else ""
    out.write(f"{indent}<field name={attr(name)}{enc_attr}>{text}</field>\n")


def export_table(out, table, args):
    """Write one <table> element. Returns (rows_written, rows_failed)."""
    columns = list(table.columns)
    out.write(f"  <table name={attr(table.name)} columns=\"{len(columns)}\">\n")
    out.write("    <columns>\n")
    for col in columns:
        out.write(
            f"      <column name={attr(col.name)} type={attr(type_name(col))}/>\n"
        )
    out.write("    </columns>\n")

    written = failed = 0
    try:
        for record in table.records():
            if args.max_rows is not None and written >= args.max_rows:
                break
            fields = []
            for col in columns:
                try:
                    value = record.get(col.name)
                except Exception as exc:  # damaged value: note it, keep going
                    fields.append((col.name, None, str(exc)))
                    continue
                if value is None and not args.include_nulls:
                    continue
                fields.append((col.name, value, None))

            out.write("    <row>\n")
            for name, value, error in fields:
                if error is not None:
                    out.write(
                        f"      <field name={attr(name)} error={attr(error)}/>\n"
                    )
                elif value is None:
                    out.write(f"      <field name={attr(name)} null=\"true\"/>\n")
                else:
                    write_field(out, name, value, args.binary, "      ")
            out.write("    </row>\n")
            written += 1
    except Exception as exc:  # damaged page or index: stop this table only
        failed += 1
        out.write(f"    <error>{clean(str(exc))}</error>\n")
        print(f"  warning: {table.name}: stopped early ({exc})", file=sys.stderr)

    out.write("  </table>\n")
    return written, failed


# ---------------------------------------------------------------------------
# Application compatibility ("shim") databases: sysmain.sdb, custom .sdb files
# ---------------------------------------------------------------------------

SDB_TAG_NAMES = {
    0x1001: "INCLUDE", 0x1002: "GENERAL", 0x1003: "MATCH_LOGIC_NOT", 0x1004:
    "APPLY_ALL_SHIMS", 0x1005: "USE_SERVICE_PACK_FILES", 0x1006: "MITIGATION_OS",
    0x1007: "BLOCK_UPGRADE", 0x1008: "INCLUDEEXCLUDEDLL", 0x1009: "RAC_EVENT_OFF",
    0x100A: "TELEMETRY_OFF", 0x100B: "SHIM_ENGINE_OFF", 0x100C:
    "LAYER_PROPAGATION_OFF", 0x100D: "REINSTALL_UPGRADE", 0x3001: "MATCH_MODE",
    0x3801: "TAG", 0x3802: "INDEX_TAG", 0x3803: "INDEX_KEY", 0x4001: "SIZE", 0x4002:
    "OFFSET", 0x4003: "CHECKSUM", 0x4004: "SHIM_TAGID", 0x4005: "PATCH_TAGID",
    0x4006: "MODULE_TYPE", 0x4007: "VERDATEHI", 0x4008: "VERDATELO", 0x4009:
    "VERFILEOS", 0x400A: "VERFILETYPE", 0x400B: "PE_CHECKSUM", 0x400C:
    "PREVOSMAJORVER", 0x400D: "PREVOSMINORVER", 0x400E: "PREVOSPLATFORMID", 0x400F:
    "PREVOSBUILDNO", 0x4010: "PROBLEMSEVERITY", 0x4011: "LANGID", 0x4012:
    "VER_LANGUAGE", 0x4014: "ENGINE", 0x4015: "HTMLHELPID", 0x4016: "INDEX_FLAGS",
    0x4017: "FLAGS", 0x4018: "DATA_VALUETYPE", 0x4019: "DATA_DWORD", 0x401A:
    "LAYER_TAGID", 0x401B: "MSI_TRANSFORM_TAGID", 0x401C: "LINKER_VERSION", 0x401D:
    "LINK_DATE", 0x401E: "UPTO_LINK_DATE", 0x401F: "OS_SERVICE_PACK", 0x4020:
    "FLAG_TAGID", 0x4021: "RUNTIME_PLATFORM", 0x4022: "OS_SKU", 0x4023:
    "OS_PLATFORM", 0x4024: "APP_NAME_RC_ID", 0x4025: "VENDOR_NAME_RC_ID", 0x4026:
    "SUMMARY_MSG_RC_ID", 0x4027: "VISTA_SKU", 0x4028: "DESCRIPTION_RC_ID", 0x4029:
    "PARAMETER1_RC_ID", 0x4030: "CONTEXT_TAGID", 0x4031: "EXE_WRAPPER", 0x4032:
    "URL_ID", 0x4801: "TAGID", 0x5001: "TIME", 0x5002: "BIN_FILE_VERSION", 0x5003:
    "BIN_PRODUCT_VERSION", 0x5004: "MODTIME", 0x5005: "FLAG_MASK_KERNEL", 0x5006:
    "UPTO_BIN_PRODUCT_VERSION", 0x5007: "DATA_QWORD", 0x5008: "FLAG_MASK_USER",
    0x5009: "FLAGS_NTVDM1", 0x500A: "FLAGS_NTVDM2", 0x500B: "FLAGS_NTVDM3", 0x500C:
    "FLAG_MASK_SHELL", 0x500D: "UPTO_BIN_FILE_VERSION", 0x500E: "FLAG_MASK_FUSION",
    0x500F: "FLAG_PROCESSPARAM", 0x5010: "FLAG_LUA", 0x5011: "FLAG_INSTALL", 0x6001:
    "NAME", 0x6002: "DESCRIPTION", 0x6003: "MODULE", 0x6004: "API", 0x6005:
    "VENDOR", 0x6006: "APP_NAME", 0x6008: "COMMAND_LINE", 0x6009: "COMPANY_NAME",
    0x600A: "DLLFILE", 0x600B: "WILDCARD_NAME", 0x6010: "PRODUCT_NAME", 0x6011:
    "PRODUCT_VERSION", 0x6012: "FILE_DESCRIPTION", 0x6013: "FILE_VERSION", 0x6014:
    "ORIGINAL_FILENAME", 0x6015: "INTERNAL_NAME", 0x6016: "LEGAL_COPYRIGHT", 0x6017:
    "16BIT_DESCRIPTION", 0x6018: "APPHELP_DETAILS", 0x6019: "LINK_URL", 0x601A:
    "LINK_TEXT", 0x601B: "APPHELP_TITLE", 0x601C: "APPHELP_CONTACT", 0x601D:
    "SXS_MANIFEST", 0x601E: "DATA_STRING", 0x601F: "MSI_TRANSFORM_FILE", 0x6020:
    "16BIT_MODULE_NAME", 0x6021: "LAYER_DISPLAYNAME", 0x6022: "COMPILER_VERSION",
    0x6023: "ACTION_TYPE", 0x6024: "EXPORT_NAME", 0x6025: "URL", 0x7001: "DATABASE",
    0x7002: "LIBRARY", 0x7003: "INEXCLUD", 0x7004: "SHIM", 0x7005: "PATCH", 0x7006:
    "APP", 0x7007: "EXE", 0x7008: "MATCHING_FILE", 0x7009: "SHIM_REF", 0x700A: "PATCH_REF", 0x700B:
    "LAYER", 0x700C: "FILE", 0x700D: "APPHELP", 0x700E: "LINK", 0x700F: "DATA",
    0x7010: "MSI_TRANSFORM", 0x7011: "MSI_TRANSFORM_REF", 0x7012: "MSI_PACKAGE",
    0x7013: "FLAG", 0x7014: "MSI_CUSTOM_ACTION", 0x7015: "FLAG_REF", 0x7016:
    "ACTION", 0x7017: "LOOKUP", 0x7018: "CONTEXT", 0x7019: "CONTEXT_REF", 0x701A:
    "KDEVICE", 0x701C: "KDRIVER", 0x7020: "SPC", 0x7025: "KSHIM", 0x7026:
    "KSHIM_REF", 0x7801: "STRINGTABLE", 0x7802: "INDEXES", 0x7803: "INDEX", 0x8801:
    "STRINGTABLE_ITEM", 0x9002: "PATCH_BITS", 0x9003: "FILE_BITS", 0x9004: "EXE_ID",
    0x9005: "DATA_BITS", 0x9006: "MSI_PACKAGE_ID", 0x9007: "DATABASE_ID", 0x9008:
    "CONTEXT_PLATFORM_ID", 0x9009: "CONTEXT_BRANCH_ID", 0x9010: "FIX_ID", 0x9011:
    "APP_ID", 0x9801: "INDEX_BITS",
}

SDB_TYPE_NAMES = {
    0x1000: "null", 0x2000: "byte", 0x3000: "word", 0x4000: "dword",
    0x5000: "qword", 0x6000: "stringref", 0x7000: "list", 0x8000: "string",
    0x9000: "binary",
}
SDB_FIXED_SIZES = {0x1000: 0, 0x2000: 1, 0x3000: 2, 0x4000: 4, 0x5000: 8, 0x6000: 4}
SDB_STRINGTABLE = 0x7801
SDB_INDEXES = 0x7802


def is_shim_sdb(header):
    """True if the file starts with a shim database header."""
    return len(header) >= 12 and header[8:12] == b"sdbf"


def sdb_element_name(tag):
    """XML element name for a tag, e.g. 0x7007 -> 'EXE'."""
    name = SDB_TAG_NAMES.get(tag)
    if name is None:
        return "TAG_0x%04X" % tag
    return "_" + name if name[0].isdigit() else name


def sdb_read_string(data, offset, size):
    raw = data[offset:offset + size]
    return raw.decode("utf-16-le", errors="replace").split("\x00", 1)[0]


def filetime_to_iso(value):
    """Windows FILETIME (100ns ticks since 1601) to ISO text, or None."""
    if not value:
        return None
    try:
        moment = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return (moment + datetime.timedelta(microseconds=value // 10)).isoformat()
    except OverflowError:
        return None


class ShimWriter:
    """Walks the tag tree of a shim database and writes it as nested XML."""

    def __init__(self, data, out, binary_mode, all_tags):
        self.data = data
        self.out = out
        self.binary_mode = binary_mode
        self.all_tags = all_tags
        self.stringtable = None  # offset of the STRINGTABLE tag
        self.count = 0
        self.warnings = 0

    def find_stringtable(self):
        """The string table is a top-level list; locate it before writing."""
        offset = 12
        while offset + 6 <= len(self.data):
            tag = struct.unpack_from("<H", self.data, offset)[0]
            if tag & 0xF000 != 0x7000:
                break
            size = struct.unpack_from("<I", self.data, offset + 2)[0]
            if tag == SDB_STRINGTABLE:
                self.stringtable = offset
                return
            offset += 6 + size + (size & 1)

    def resolve(self, ref):
        """Follow a string reference into the string table."""
        if self.stringtable is None or ref == 0:
            return None
        item = self.stringtable + ref
        if item + 6 > len(self.data):
            return None
        size = struct.unpack_from("<I", self.data, item + 2)[0]
        return sdb_read_string(self.data, item + 6, size)

    def walk(self, offset, end, depth):
        data, out = self.data, self.out
        pad = "  " * depth
        while offset + 2 <= end:
            tag = struct.unpack_from("<H", data, offset)[0]
            kind = tag & 0xF000
            if kind not in SDB_TYPE_NAMES:
                # Single-byte values may be followed by one padding byte.
                offset += 1
                self.warnings += 1
                continue
            name = sdb_element_name(tag)
            offset += 2
            self.count += 1

            if kind in SDB_FIXED_SIZES:
                size = SDB_FIXED_SIZES[kind]
                if offset + size > end:
                    out.write(f"{pad}<error>truncated {name}</error>\n")
                    return
                raw = data[offset:offset + size]
                offset += size
                if kind == 0x1000:
                    out.write(f"{pad}<{name}/>\n")
                elif kind == 0x6000:
                    text = self.resolve(struct.unpack("<I", raw)[0])
                    if text is None:
                        out.write(f"{pad}<{name}/>\n")
                    else:
                        out.write(f"{pad}<{name}>{clean(text)}</{name}>\n")
                else:
                    value = int.from_bytes(raw, "little")
                    extra = f' hex="0x{value:0{size * 2}X}"' if size >= 4 else ""
                    if kind == 0x5000 and "TIME" in name:
                        iso = filetime_to_iso(value)
                        if iso:
                            extra += f' time="{iso}"'
                    out.write(f"{pad}<{name}{extra}>{value}</{name}>\n")
                continue

            if offset + 4 > end:
                out.write(f"{pad}<error>truncated {name}</error>\n")
                return
            size = struct.unpack_from("<I", data, offset)[0]
            offset += 4
            body_end = offset + size
            if body_end > end:
                out.write(f"{pad}<error>{name} runs past its parent</error>\n")
                self.warnings += 1
                body_end = end

            if kind == 0x7000:
                skip = tag in (SDB_STRINGTABLE, SDB_INDEXES) and not self.all_tags
                if not skip:
                    out.write(f"{pad}<{name}>\n")
                    self.walk(offset, body_end, depth + 1)
                    out.write(f"{pad}</{name}>\n")
            elif kind == 0x8000:
                text = sdb_read_string(data, offset, body_end - offset)
                out.write(f"{pad}<{name}>{clean(text)}</{name}>\n")
            else:
                raw = bytes(data[offset:body_end])
                extra = ""
                if len(raw) == 16 and name.endswith("_ID"):
                    extra = f' guid="{uuid.UUID(bytes_le=raw)}"'
                text, enc = format_scalar(raw, self.binary_mode)
                out.write(f'{pad}<{name} encoding="{enc}"{extra}>{text}</{name}>\n')
            offset = body_end + (size & 1)


def convert_shim(src, dst, args):
    """Convert an application compatibility database to XML."""
    data = src.read_bytes()
    major, minor = struct.unpack_from("<II", data, 0)
    with dst.open("w", encoding="utf-8", newline="\n") as out:
        out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        out.write(
            f'<sdb source={attr(src.name)} format="shim" '
            f'version="{major}.{minor}">\n'
        )
        writer = ShimWriter(data, out, args.binary, args.all_tags)
        writer.find_stringtable()
        writer.walk(12, len(data), 1)
        out.write("</sdb>\n")
    note = f" ({writer.warnings} unreadable spots skipped)" if writer.warnings else ""
    print(f"Wrote {writer.count} tags to {dst}{note}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Heidelberg Engineering HEYEX / Spectralis files: .sdb .edb .pdb .E2E
#
# The layout follows the reverse-engineered descriptions published by the
# eyepy, OCT-Converter and LibE2E projects. Heidelberg does not document the
# format, so unknown record types are kept as raw bytes rather than dropped.
# ---------------------------------------------------------------------------

HEYEX_IMAGE = 0x40000000
HEYEX_TYPE_NAMES = {
    2: "preview_image", 3: "type_3", 5: "type_5", 7: "measurements",
    9: "patient", 11: "laterality", 13: "application_data", 17: "diagnose",
    39: "localizer_settings", 59: "type_59",
    9000: "study_name", 9001: "device", 9005: "examined_structure",
    9006: "scan_pattern", 9007: "enface_modality", 9008: "oct_modality",
    10004: "bscan_metadata", 10005: "examination_time", 10010: "type_10010",
    10012: "type_10012", 10013: "type_10013", 10019: "layer_annotation",
    10025: "localizer_metadata", HEYEX_IMAGE: "image",
}
HEYEX_STRING_LISTS = {17, 9000, 9001, 9005, 9006, 9007, 9008}
HEYEX_LATERALITY_OFFSET = {11: 14, 59: 14, 3: 4, 5: 2}
HEYEX_IMG_FUNDUS = 33620481   # 8-bit greyscale
HEYEX_IMG_BSCAN = 35652097    # 16-bit unsigned float
HEYEX_RAW_LIMIT = 65536       # largest unknown record written out in full

HEYEX_BSCAN_META = [
    ("unknown0", "I"), ("size_y", "I"), ("size_x", "I"),
    ("start_x", "f"), ("start_y", "f"), ("end_x", "f"), ("end_y", "f"),
    ("zero1", "I"), ("unknown1", "f"), ("scale_y", "f"), ("unknown2", "f"),
    ("zero2", "I"), ("unknown3a", "f"), ("unknown3b", "f"), ("zero3", "I"),
    ("img_size_width", "I"), ("n_bscans", "I"), ("bscan_index", "I"),
    ("scan_pattern", "I"), ("center_x", "f"), ("center_y", "f"),
    ("unknown4", "I"), ("acquisition_time", "Q"), ("num_averages", "I"),
    ("quality", "f"), ("unknown5", "f"), ("unknown6", "12s"),
    ("art_mode", "I"), ("oct_controller_fw", "4s"), ("oct_camera_fw", "4s"),
    ("oct_camera_fpga", "4s"), ("unknown7", "4s"), ("focus_candidate", "f"),
    ("unknown8", "12s"), ("quality_ui", "f"),
]
HEYEX_MEASUREMENTS = [
    ("c_curve_mm", "d"), ("refraction_dpt", "d"), ("cylinder_dpt", "d"),
    ("axis_deg", "d"), ("pupil_size_mm", "d"), ("iop_mmHg", "d"),
    ("vfield_mean", "d"), ("vfield_var", "d"), ("corrective_lens", "H"),
]


def is_heyex(header):
    """True if the file starts with the Heidelberg container signature."""
    return header[:4] == b"CMDb"


def heyex_text(raw, encoding="latin-1"):
    return raw.split(b"\x00", 1)[0].decode(encoding, errors="replace").strip()


def heyex_laterality(code):
    return {82: "OD", 76: "OS"}.get(code)


def heyex_unpack(data, layout, offset=0):
    """Decode as many fields of a fixed layout as the record contains."""
    fields = []
    for name, fmt in layout:
        size = struct.calcsize("<" + fmt)
        if offset + size > len(data):
            break
        value = struct.unpack_from("<" + fmt, data, offset)[0]
        offset += size
        fields.append((name, value))
    return fields


def heyex_birthdate(raw):
    """Best-effort birth date. Readers disagree on this field, so the raw
    number is always written alongside it."""
    text = str(raw)
    if len(text) == 8 and 1850 <= int(text[:4]) <= 2100:
        try:
            return datetime.date(int(text[:4]), int(text[4:6]), int(text[6:])).isoformat()
        except ValueError:
            pass
    try:
        day = datetime.date.fromordinal(int(raw / 64 - 14558805) - 1721425)
    except (ValueError, OverflowError):
        return None
    return day.isoformat() if 1850 <= day.year <= 2100 else None


def heyex_decode(kind, data):
    """Turn one record into a list of (name, value) pairs, or None if the
    record type is not understood."""
    if kind == 9 and len(data) >= 127:
        raw_birth = struct.unpack_from("<I", data, 97)[0]
        fields = [
            ("firstname", heyex_text(data[0:31])),
            ("surname", heyex_text(data[31:97])),
            ("birthdate_raw", raw_birth),
            ("sex", heyex_text(data[101:102])),
            ("patient_id", heyex_text(data[102:127])),
        ]
        birth = heyex_birthdate(raw_birth)
        if birth:
            fields.insert(3, ("birthdate", birth))
        return fields

    if kind == 7 and len(data) >= 1:
        fields = [("eye_side", heyex_laterality(data[0]) or data[0])]
        return fields + heyex_unpack(data, HEYEX_MEASUREMENTS, 1)

    if kind in HEYEX_LATERALITY_OFFSET:
        offset = HEYEX_LATERALITY_OFFSET[kind]
        side = heyex_laterality(data[offset]) if len(data) > offset else None
        fields = [("laterality", side)] if side else []
        return fields + [("raw", bytes(data))]

    if kind in HEYEX_STRING_LISTS and len(data) >= 8:
        count, size = struct.unpack_from("<II", data, 0)
        body = len(data) - 8
        if count and size and count * size * 2 <= body and count * size != body:
            size *= 2   # length was given in characters
        if not count or not size or count * size > body:
            return None
        texts = [
            heyex_text(data[8 + i * size:8 + (i + 1) * size].decode("utf-16-le", "replace").encode("utf-8"), "utf-8")
            for i in range(count)
        ]
        return [("text", texts)]

    if kind == 13:
        parts = [p.strip() for p in data.decode("utf-16-le", "ignore").split("\x00")]
        return [("text", [p for p in parts if p])]

    if kind == 10004:
        fields = []
        for name, value in heyex_unpack(data, HEYEX_BSCAN_META):
            if name == "acquisition_time":
                value = filetime_to_iso(value) or value
            elif name.startswith("oct_"):
                value = ".".join(str(b) for b in value)
            fields.append((name, value))
        return fields

    if kind == 10005 and len(data) >= 24:
        ticks = struct.unpack_from("<Q", data, 16)[0]
        return [("examination_time", filetime_to_iso(ticks) or ticks)]

    if kind in (10010, 10013) and len(data) >= 16:
        return [("n_bscans", struct.unpack_from("<I", data, 12)[0]), ("raw", bytes(data))]

    if kind == 10012 and len(data) >= 37:
        return [
            ("value_1", struct.unpack_from("<f", data, 28)[0]),
            ("value_2", struct.unpack_from("<f", data, 33)[0]),
            ("raw", bytes(data)),
        ]

    if kind == 10019 and len(data) >= 20:
        _, layer, _, width, edited = struct.unpack_from("<5I", data, 0)
        fields = [("layer_id", layer), ("width", width), ("manually_edited", bool(edited))]
        start = len(data) - width * 4
        if width and start >= 20:
            values = struct.unpack_from(f"<{width}f", data, start)
            fields.append(("values", " ".join(
                "nan" if (v != v or abs(v) > 1e30) else f"{v:.3f}" for v in values)))
        return fields

    if kind == 10025 and len(data) >= 56:
        ticks = struct.unpack_from("<Q", data, 24)[0]
        return [
            ("time", filetime_to_iso(ticks) or ticks),
            ("transform", list(struct.unpack_from("<6f", data, 32))),
        ]

    return None


def png_bytes(width, height, pixels):
    """Encode 8-bit greyscale pixels as a PNG file."""
    import zlib

    def chunk(tag, body):
        return (struct.pack(">I", len(body)) + tag + body
                + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF))

    stride = width
    rows = b"".join(b"\x00" + pixels[y * stride:(y + 1) * stride] for y in range(height))
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows, 6))
            + chunk(b"IEND", b""))


_BSCAN_LUT = None


def bscan_lut():
    """Lookup table from the 16-bit float used for B-scans (6-bit exponent,
    10-bit mantissa, no sign) to an 8-bit display value. Intensities are
    shown with a fourth-root curve, as OCT viewers usually do."""
    global _BSCAN_LUT
    if _BSCAN_LUT is None:
        lut = bytearray(65536)
        for raw in range(65536):
            value = (1 + (raw & 0x3FF) / 1024) * 2.0 ** ((raw >> 10) - 63)
            if value <= 1.0:   # larger values mark pixels with no signal
                lut[raw] = min(255, int(round(255 * value ** 0.25)))
        _BSCAN_LUT = bytes(lut)
    return _BSCAN_LUT


def heyex_image(data):
    """Decode an image record. Returns (info fields, extension, file bytes);
    the last two are None when the pixel format is not understood."""
    if len(data) < 20:
        return [], None, None
    size, subtype, count, height, width = struct.unpack_from("<5I", data, 0)
    info = [("image_type", subtype), ("width", width), ("height", height)]
    pixels = width * height
    body = memoryview(data)[20:]
    if subtype == HEYEX_IMG_FUNDUS and pixels and len(body) >= pixels:
        info.insert(0, ("kind", "fundus"))
        return info, "png", png_bytes(width, height, bytes(body[:pixels]))
    if subtype == HEYEX_IMG_BSCAN and pixels and len(body) >= pixels * 2:
        import array
        values = array.array("H")
        values.frombytes(bytes(body[:pixels * 2]))
        if sys.byteorder == "big":
            values.byteswap()
        lut = bscan_lut()
        info.insert(0, ("kind", "bscan"))
        return info, "png", png_bytes(width, height, bytes(map(lut.__getitem__, values)))
    info.insert(0, ("kind", "unknown"))
    return info, None, None


def heyex_directory(fh, file_size):
    """Yield every directory entry in the file, oldest chunk first."""
    fh.seek(36)
    main = fh.read(52)
    if main[:7] != b"MDbMDir":
        raise ValueError("missing main directory (MDbMDir)")
    _, current, previous = struct.unpack_from("<III", main, 36)

    def is_chunk(position):
        if not position or position + 52 > file_size:
            return False
        fh.seek(position)
        return fh.read(6) == b"MDbDir"

    position = current if is_chunk(current) else previous
    chunks, seen = [], set()
    while is_chunk(position) and position not in seen:
        seen.add(position)
        fh.seek(position)
        head = fh.read(52)
        count, _, before = struct.unpack_from("<III", head, 36)
        chunks.append(fh.read(44 * min(count, 65536)))
        position = before

    for raw in reversed(chunks):
        for i in range(len(raw) // 44):
            (_, start, size, _, patient, study, series, slice_id, ind, _, kind,
             _) = struct.unpack_from("<IIIIiiiiHHII", raw, i * 44)
            if kind == 0 or start == 0 or start + 60 > file_size:
                continue
            yield {"start": start, "size": size, "patient": patient, "study": study,
                   "series": series, "slice": slice_id, "ind": ind, "type": kind}


def heyex_read(fh, entry, file_size):
    """Read the data of one directory entry."""
    fh.seek(entry["start"])
    head = fh.read(60)
    size = entry["size"]
    if head[:7] == b"MDbData":
        size = struct.unpack_from("<I", head, 24)[0] or size
    size = max(0, min(size, file_size - entry["start"] - 60))
    return fh.read(size)


MM_PER_DEGREE = 0.2961          # retina scale used by Spectralis for scan angles
ETDRS_STEP_MM = 0.01157         # sampling pitch of the grid (one localizer pixel)


def heyex_thickness_grids(fh, entries, file_size):
    """Build ETDRS (1/3/6 mm) thickness grids from B-scan geometry + ILM/BM lines.

    HEYEX does not store the grid; it is computed from the ILM (layer 0) and
    BM (layer 1) segmentation of each B-scan (record 10019), the B-scan
    positions and scale (record 10004) and the eye side (record 11).
    Returns a list of dicts, one per series that has a full volume.
    """
    eye = "OD"
    series = {}
    for e in entries:
        kind = e["type"]
        key = (e["patient"], e["study"], e["series"])
        try:
            if kind == 11:
                fields = dict(heyex_decode(kind, heyex_read(fh, e, file_size)) or [])
                if fields.get("laterality") in ("OD", "OS"):
                    eye = fields["laterality"]
            elif kind in (10004, 10019) and e["series"] >= 0 and e["slice"] >= 0:
                data = heyex_read(fh, e, file_size)
                fields = dict(heyex_decode(kind, data) or [])
                slot = series.setdefault(key, {}).setdefault(e["slice"], {})
                if kind == 10004:
                    slot["meta"] = fields
                elif fields.get("values") is not None:
                    slot.setdefault("layers", {})[fields["layer_id"]] = [
                        float(v) for v in fields["values"].split()]
        except Exception:
            continue

    grids = []
    for key, slices in series.items():
        rows = []
        for sl in sorted(slices):
            meta, layers = slices[sl].get("meta"), slices[sl].get("layers", {})
            if not meta or 0 not in layers or 1 not in layers:
                continue
            ilm, bm = layers[0], layers[1]
            scale = meta["scale_y"]
            line = [(b - a) * scale if (a == a and b == b) else float("nan")
                    for a, b in zip(ilm, bm)]
            rows.append((meta["start_y"], meta["start_x"], meta["end_x"], line))
        if len(rows) < 3:
            continue
        rows.sort(key=lambda r: -r[0])           # first B-scan = largest y
        ys = [r[0] for r in rows]
        step_deg = (ys[0] - ys[-1]) / (len(ys) - 1)
        if step_deg <= 0:
            continue
        x0, x1, n = rows[0][1], rows[0][2], len(rows[0][3])

        def thickness(x_deg, y_deg):
            fy = (ys[0] - y_deg) / step_deg
            fx = (x_deg - x0) / (x1 - x0) * (n - 1)
            if fy < 0 or fy > len(rows) - 1 or fx < 0 or fx > n - 1:
                return None
            value = rows[min(int(round(fy)), len(rows) - 1)][3][min(int(round(fx)), n - 1)]
            return None if value != value else value

        zones = {}
        count = int(3.0 / ETDRS_STEP_MM) + 2
        for j in range(-count, count + 1):
            for i in range(-count, count + 1):
                xm, ym = (i + 0.5) * ETDRS_STEP_MM, (j + 0.5) * ETDRS_STEP_MM
                r = math.hypot(xm, ym)
                if r > 3.0:
                    continue
                if r < 0.5:
                    zone = "C0"
                else:
                    ang = math.degrees(math.atan2(ym, xm)) % 360   # x right, y up
                    quad = ("S" if 45 <= ang < 135 else "T" if 135 <= ang < 225
                            else "I" if 225 <= ang < 315 else "N")
                    if eye == "OS":                      # nasal is on the left for a left eye
                        quad = {"T": "N", "N": "T"}.get(quad, quad)
                    zone = quad + ("1" if r < 1.5 else "2")
                acc = zones.setdefault(zone, [0.0, 0, 0, None, None])
                acc[2] += 1
                v = thickness(xm / MM_PER_DEGREE, -ym / MM_PER_DEGREE)
                if v is not None:
                    acc[0] += v
                    acc[1] += 1
                    if zone == "C0":
                        acc[3] = v if acc[3] is None else min(acc[3], v)
                        acc[4] = v if acc[4] is None else max(acc[4], v)
        if "C0" not in zones or not zones["C0"][1]:
            continue
        mid = rows[len(rows) // 2]
        center = thickness(0.0, 0.0)
        areas = {"C0": math.pi * 0.25}
        for q in "NSTI":
            areas[q + "1"] = math.pi * (1.5 ** 2 - 0.5 ** 2) / 4
            areas[q + "2"] = math.pi * (3.0 ** 2 - 1.5 ** 2) / 4
        out_zones = []
        total = 0.0
        for name in ("C0", "N1", "N2", "S1", "S2", "T1", "T2", "I1", "I2"):
            if name not in zones or not zones[name][1]:
                continue
            total_px, ok_px = zones[name][2], zones[name][1]
            avg = zones[name][0] / ok_px
            vol = avg * areas[name]
            total += vol
            out_zones.append((name, avg, vol, 100.0 * ok_px / total_px))
        grids.append({
            "patient": key[0], "study": key[1], "series": key[2], "eye": eye,
            "center": center, "min": zones["C0"][3], "max": zones["C0"][4],
            "volume": total, "zones": out_zones,
        })
    return grids


def write_thickness_grids(out, grids):
    for g in grids:
        out.write(
            f'  <thickness_grid patient="{g["patient"]}" study="{g["study"]}" '
            f'series="{g["series"]}" laterality="{g["eye"]}" type="ETDRS" '
            f'diameters_mm="1.00 3.00 6.00" unit="mm">\n')
        if g["center"] is not None:
            out.write(f'    <central_thickness>{g["center"]:.3f}</central_thickness>\n')
        out.write(f'    <min_central_thickness>{g["min"]:.3f}</min_central_thickness>\n')
        out.write(f'    <max_central_thickness>{g["max"]:.3f}</max_central_thickness>\n')
        out.write(f'    <total_volume>{g["volume"]:.3f}</total_volume>\n')
        for name, avg, vol, valid in g["zones"]:
            out.write(
                f'    <zone name="{name}"><avg_thickness>{avg:.3f}</avg_thickness>'
                f'<volume>{vol:.3f}</volume>'
                f'<valid_pixel_percentage>{valid:.3f}</valid_pixel_percentage></zone>\n')
        out.write("  </thickness_grid>\n")


def convert_heyex(src, dst, args):
    """Convert a Heidelberg HEYEX / Spectralis file to XML."""
    file_size = src.stat().st_size
    image_dir = Path(args.images) if args.images else None
    if image_dir:
        image_dir.mkdir(parents=True, exist_ok=True)
    level_names = ("patient", "study", "series", "slice")
    records = images = failed = 0
    used_names = set()

    with src.open("rb") as fh, dst.open("w", encoding="utf-8", newline="\n") as out:
        version = struct.unpack_from("<I", fh.read(16), 12)[0]
        try:
            entries = list(heyex_directory(fh, file_size))
        except (ValueError, struct.error) as exc:
            sys.exit(f"Could not read {src.name} as a Heidelberg file: {exc}")
        order = {id(e): i for i, e in enumerate(entries)}
        entries.sort(key=lambda e: (e["patient"], e["study"], e["series"], e["slice"], order[id(e)]))

        out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        out.write(
            f'<heyex source={attr(src.name)} format="heidelberg" '
            f'version="{version}" records="{len(entries)}">\n'
        )
        open_levels = []   # ids of the currently open patient/study/series/slice

        for entry in entries:
            ids = [entry["patient"], entry["study"], entry["series"], entry["slice"]]
            path = []
            for value in ids:
                if value < 0:
                    break
                path.append(value)
            keep = 0
            while keep < min(len(path), len(open_levels)) and path[keep] == open_levels[keep]:
                keep += 1
            while len(open_levels) > keep:
                open_levels.pop()
                out.write(f"{'  ' * (len(open_levels) + 1)}</{level_names[len(open_levels)]}>\n")
            while len(open_levels) < len(path):
                depth = len(open_levels)
                out.write(f"{'  ' * (depth + 1)}<{level_names[depth]} id=\"{path[depth]}\">\n")
                open_levels.append(path[depth])

            pad = "  " * (len(open_levels) + 1)
            kind = entry["type"]
            name = HEYEX_TYPE_NAMES.get(kind, "unknown")
            head = (f'{pad}<record type="{kind}" name="{name}" index="{entry["ind"]}" '
                    f'size="{entry["size"]}"')
            try:
                data = heyex_read(fh, entry, file_size)
                extension = payload = None
                if kind == HEYEX_IMAGE:
                    fields, extension, payload = heyex_image(data)
                elif kind == 2 and b"\xff\xd8\xff" in data[:64]:
                    fields = [("kind", "preview")]
                    extension, payload = "jpg", data[data.index(b"\xff\xd8\xff"):]
                else:
                    fields = heyex_decode(kind, data)

                if payload is not None:
                    images += 1
                    if image_dir:
                        ids_text = "_".join("x" if v < 0 else str(v) for v in ids)
                        label = dict(fields).get("kind", "image")
                        file_name = f"{src.stem}_{ids_text}_{label}.{extension}"
                        n = 1
                        while file_name in used_names:
                            n += 1
                            file_name = f"{src.stem}_{ids_text}_{label}_{n}.{extension}"
                        used_names.add(file_name)
                        (image_dir / file_name).write_bytes(payload)
                        fields.append(("file", file_name))

                if fields is None:
                    if len(data) <= HEYEX_RAW_LIMIT:
                        fields = [("raw", bytes(data))]
                    else:
                        fields = []
                        head += ' omitted="too large"'
                out.write(head + (">\n" if fields else "/>\n"))
                for field_name, value in fields:
                    if isinstance(value, float):
                        value = repr(round(value, 6))
                    elif isinstance(value, list):
                        value = [round(v, 6) if isinstance(v, float) else v for v in value]
                    write_field(out, field_name, value, args.binary, pad + "  ")
                if fields:
                    out.write(f"{pad}</record>\n")
            except Exception as exc:  # damaged record: note it, keep going
                failed += 1
                out.write(head + f" error={attr(str(exc))}/>\n")
            records += 1

        while open_levels:
            open_levels.pop()
            out.write(f"{'  ' * (len(open_levels) + 1)}</{level_names[len(open_levels)]}>\n")
        try:
            write_thickness_grids(out, heyex_thickness_grids(fh, entries, file_size))
        except Exception as exc:
            out.write(f"  <!-- thickness grid not computed: {clean(str(exc))} -->\n")
        out.write("</heyex>\n")

    note = f", {failed} unreadable" if failed else ""
    where = f" (saved to {image_dir})" if image_dir else ""
    print(f"Wrote {records} records, {images} images{where}{note} to {dst}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description="Convert .edb / .sdb / .pdb / .E2E database files to XML."
    )
    parser.add_argument("input", help="path to the database file")
    parser.add_argument("-o", "--output", help="output XML path (default: <input>.xml)")
    parser.add_argument(
        "-t", "--table", action="append", default=[],
        help="export only this table (repeat for several)",
    )
    parser.add_argument("--list", action="store_true", help="list tables and exit")
    parser.add_argument(
        "--max-rows", type=int, default=None,
        help="export at most this many rows per table",
    )
    parser.add_argument(
        "--binary", choices=("hex", "base64"), default="hex",
        help="how to encode binary columns (default: hex)",
    )
    parser.add_argument(
        "--include-nulls", action="store_true",
        help="write empty columns as <field null=\"true\"/> instead of omitting them",
    )
    parser.add_argument(
        "--skip-system", action="store_true",
        help="skip the internal MSys* catalog tables",
    )
    parser.add_argument(
        "--images", metavar="DIR",
        help="Heidelberg files only: also save the scan images into this folder",
    )
    parser.add_argument(
        "--all-tags", action="store_true",
        help="shim .sdb only: also write the string table and lookup indexes",
    )
    args = parser.parse_args()

    src = Path(args.input)
    if not src.is_file():
        sys.exit(f"File not found: {src}")

    dst = Path(args.output) if args.output else src.with_suffix(".xml")

    with src.open("rb") as fh:
        header = fh.read(12)
    if is_heyex(header):
        if args.list or args.table:
            sys.exit(
                f"{src.name} is a Heidelberg eye-scan file; it has no tables, "
                "so --list and --table do not apply."
            )
        convert_heyex(src, dst, args)
        return
    if is_shim_sdb(header):
        if args.list or args.table:
            sys.exit(
                f"{src.name} is an application compatibility database; it has "
                "no tables, so --list and --table do not apply."
            )
        convert_shim(src, dst, args)
        return

    if EseDB is None:
        sys.exit("Missing dependency. Install it with:  pip install dissect.esedb")

    with src.open("rb") as fh:
        try:
            db = EseDB(fh)
            tables = list(db.tables())
        except Exception as exc:
            message = (
                f"{src.name} was not recognised as a Heidelberg, Windows ESE or "
                f"compatibility database ({exc})."
            )
            if "signature" not in str(exc):
                message += (
                    "\nIf this is a Windows database copied from a running system "
                    "it may be in a 'dirty shutdown' state; repair a COPY first "
                    "with:  esentutl /p <copy.edb>"
                )
            sys.exit(message)

        if args.list:
            for table in tables:
                print(f"{table.name}  ({len(list(table.columns))} columns)")
            return

        if args.table:
            wanted = {name.lower() for name in args.table}
            found = {t.name.lower() for t in tables}
            missing = sorted(wanted - found)
            if missing:
                sys.exit(
                    "Table(s) not found: " + ", ".join(missing)
                    + "\nRun with --list to see the available tables."
                )
            tables = [t for t in tables if t.name.lower() in wanted]

        if args.skip_system:
            tables = [t for t in tables if not t.name.startswith("MSys")]

        total_rows = 0
        with dst.open("w", encoding="utf-8", newline="\n") as out:
            out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            out.write(f"<database source={attr(src.name)}>\n")
            for table in tables:
                rows, _ = export_table(out, table, args)
                total_rows += rows
                print(f"  {table.name}: {rows} rows", file=sys.stderr)
            out.write("</database>\n")

    print(f"Wrote {len(tables)} tables, {total_rows} rows to {dst}", file=sys.stderr)


if __name__ == "__main__":
    main()
