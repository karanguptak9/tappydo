#!/usr/bin/env python3
"""
edb2xml.py - Convert Windows .edb and .sdb database files to XML.

The file type is detected from its contents, not its extension:
  - ESE databases (.edb, and the security database secedit.sdb)
    become <database> / <table> / <row> XML.
  - Application compatibility "shim" databases (sysmain.sdb, custom .sdb)
    become nested XML that mirrors the tag tree (DATABASE, EXE, LAYER, ...).

Works with Extensible Storage Engine (JET Blue) files such as:
  - Windows Search index   (Windows.edb)
  - Exchange mailbox stores (*.edb)
  - SRUM                    (SRUDB.dat)
  - Active Directory        (ntds.dit)
  - Windows Update, WebCache, and other ESE databases

Requires:  pip install dissect.esedb   (ESE databases only; shim .sdb files
           need nothing beyond Python 3.8+)

Usage:
  python edb2xml.py Windows.edb                     # writes Windows.xml
  python edb2xml.py Windows.edb -o out.xml
  python edb2xml.py Windows.edb --list              # show tables and exit
  python edb2xml.py Windows.edb -t MSysObjects -t SystemIndex_Gthr
  python edb2xml.py Windows.edb --max-rows 1000 --binary base64
  python edb2xml.py sysmain.sdb                     # writes sysmain.xml

Output shape:
  <database source="Windows.edb">
    <table name="MyTable" columns="3">
      <columns>
        <column name="Id" type="Long"/>
      </columns>
      <row>
        <field name="Id">1</field>
      </row>
    </table>
  </database>

The file is opened read-only and the XML is streamed to disk, so large
databases do not need to fit in memory.
"""

import argparse
import base64
import datetime
import re
import struct
import sys
import uuid
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

try:
    from dissect.esedb import EseDB
except ImportError:  # only needed for ESE databases, not shim .sdb files
    EseDB = None

# Characters that are not allowed in XML 1.0 documents.
_INVALID_XML = re.compile(
    "[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]|[\ud800-\udfff]"
)


def clean(text):
    """Escape a string for XML, replacing characters XML cannot hold."""
    text = _INVALID_XML.sub(lambda m: "\\x%02x" % ord(m.group()), text)
    return escape(text)


def attr(text):
    """Quote a string for use as an XML attribute value."""
    return quoteattr(_INVALID_XML.sub("?", str(text)))


def type_name(column):
    """Readable JET column type, e.g. 'Long', 'LongText', 'DateTime'."""
    name = getattr(column.type, "name", None) or str(column.type)
    return name.replace("JET_coltyp", "").strip("._") or "Unknown"


def format_scalar(value, binary_mode):
    """Return (text, encoding) for a single non-list value."""
    if isinstance(value, (bytes, bytearray, memoryview)):
        data = bytes(value)
        if binary_mode == "base64":
            return base64.b64encode(data).decode("ascii"), "base64"
        return data.hex(), "hex"
    if isinstance(value, datetime.datetime):
        return value.isoformat(), None
    if isinstance(value, bool):
        return ("true" if value else "false"), None
    if isinstance(value, uuid.UUID):
        return str(value), None
    return clean(str(value)), None


def write_field(out, name, value, binary_mode, indent):
    """Write one <field> element. Multi-valued columns get <value> children."""
    if isinstance(value, (list, tuple)):
        out.write(f"{indent}<field name={attr(name)} multi=\"true\">\n")
        for item in value:
            if item is None:
                out.write(f"{indent}  <value null=\"true\"/>\n")
                continue
            text, enc = format_scalar(item, binary_mode)
            enc_attr = f" encoding=\"{enc}\"" if enc else ""
            out.write(f"{indent}  <value{enc_attr}>{text}</value>\n")
        out.write(f"{indent}</field>\n")
        return

    text, enc = format_scalar(value, binary_mode)
    enc_attr = f" encoding=\"{enc}\"" if enc else ""
    out.write(f"{indent}<field name={attr(name)}{enc_attr}>{text}</field>\n")


def export_table(out, table, args):
    """Write one <table> element. Returns (rows_written, rows_failed)."""
    columns = list(table.columns)
    out.write(f"  <table name={attr(table.name)} columns=\"{len(columns)}\">\n")
    out.write("    <columns>\n")
    for col in columns:
        out.write(
            f"      <column name={attr(col.name)} type={attr(type_name(col))}/>\n"
        )
    out.write("    </columns>\n")

    written = failed = 0
    try:
        for record in table.records():
            if args.max_rows is not None and written >= args.max_rows:
                break
            fields = []
            for col in columns:
                try:
                    value = record.get(col.name)
                except Exception as exc:  # damaged value: note it, keep going
                    fields.append((col.name, None, str(exc)))
                    continue
                if value is None and not args.include_nulls:
                    continue
                fields.append((col.name, value, None))

            out.write("    <row>\n")
            for name, value, error in fields:
                if error is not None:
                    out.write(
                        f"      <field name={attr(name)} error={attr(error)}/>\n"
                    )
                elif value is None:
                    out.write(f"      <field name={attr(name)} null=\"true\"/>\n")
                else:
                    write_field(out, name, value, args.binary, "      ")
            out.write("    </row>\n")
            written += 1
    except Exception as exc:  # damaged page or index: stop this table only
        failed += 1
        out.write(f"    <error>{clean(str(exc))}</error>\n")
        print(f"  warning: {table.name}: stopped early ({exc})", file=sys.stderr)

    out.write("  </table>\n")
    return written, failed


# ---------------------------------------------------------------------------
# Application compatibility ("shim") databases: sysmain.sdb, custom .sdb files
# ---------------------------------------------------------------------------

SDB_TAG_NAMES = {
    0x1001: "INCLUDE", 0x1002: "GENERAL", 0x1003: "MATCH_LOGIC_NOT", 0x1004:
    "APPLY_ALL_SHIMS", 0x1005: "USE_SERVICE_PACK_FILES", 0x1006: "MITIGATION_OS",
    0x1007: "BLOCK_UPGRADE", 0x1008: "INCLUDEEXCLUDEDLL", 0x1009: "RAC_EVENT_OFF",
    0x100A: "TELEMETRY_OFF", 0x100B: "SHIM_ENGINE_OFF", 0x100C:
    "LAYER_PROPAGATION_OFF", 0x100D: "REINSTALL_UPGRADE", 0x3001: "MATCH_MODE",
    0x3801: "TAG", 0x3802: "INDEX_TAG", 0x3803: "INDEX_KEY", 0x4001: "SIZE", 0x4002:
    "OFFSET", 0x4003: "CHECKSUM", 0x4004: "SHIM_TAGID", 0x4005: "PATCH_TAGID",
    0x4006: "MODULE_TYPE", 0x4007: "VERDATEHI", 0x4008: "VERDATELO", 0x4009:
    "VERFILEOS", 0x400A: "VERFILETYPE", 0x400B: "PE_CHECKSUM", 0x400C:
    "PREVOSMAJORVER", 0x400D: "PREVOSMINORVER", 0x400E: "PREVOSPLATFORMID", 0x400F:
    "PREVOSBUILDNO", 0x4010: "PROBLEMSEVERITY", 0x4011: "LANGID", 0x4012:
    "VER_LANGUAGE", 0x4014: "ENGINE", 0x4015: "HTMLHELPID", 0x4016: "INDEX_FLAGS",
    0x4017: "FLAGS", 0x4018: "DATA_VALUETYPE", 0x4019: "DATA_DWORD", 0x401A:
    "LAYER_TAGID", 0x401B: "MSI_TRANSFORM_TAGID", 0x401C: "LINKER_VERSION", 0x401D:
    "LINK_DATE", 0x401E: "UPTO_LINK_DATE", 0x401F: "OS_SERVICE_PACK", 0x4020:
    "FLAG_TAGID", 0x4021: "RUNTIME_PLATFORM", 0x4022: "OS_SKU", 0x4023:
    "OS_PLATFORM", 0x4024: "APP_NAME_RC_ID", 0x4025: "VENDOR_NAME_RC_ID", 0x4026:
    "SUMMARY_MSG_RC_ID", 0x4027: "VISTA_SKU", 0x4028: "DESCRIPTION_RC_ID", 0x4029:
    "PARAMETER1_RC_ID", 0x4030: "CONTEXT_TAGID", 0x4031: "EXE_WRAPPER", 0x4032:
    "URL_ID", 0x4801: "TAGID", 0x5001: "TIME", 0x5002: "BIN_FILE_VERSION", 0x5003:
    "BIN_PRODUCT_VERSION", 0x5004: "MODTIME", 0x5005: "FLAG_MASK_KERNEL", 0x5006:
    "UPTO_BIN_PRODUCT_VERSION", 0x5007: "DATA_QWORD", 0x5008: "FLAG_MASK_USER",
    0x5009: "FLAGS_NTVDM1", 0x500A: "FLAGS_NTVDM2", 0x500B: "FLAGS_NTVDM3", 0x500C:
    "FLAG_MASK_SHELL", 0x500D: "UPTO_BIN_FILE_VERSION", 0x500E: "FLAG_MASK_FUSION",
    0x500F: "FLAG_PROCESSPARAM", 0x5010: "FLAG_LUA", 0x5011: "FLAG_INSTALL", 0x6001:
    "NAME", 0x6002: "DESCRIPTION", 0x6003: "MODULE", 0x6004: "API", 0x6005:
    "VENDOR", 0x6006: "APP_NAME", 0x6008: "COMMAND_LINE", 0x6009: "COMPANY_NAME",
    0x600A: "DLLFILE", 0x600B: "WILDCARD_NAME", 0x6010: "PRODUCT_NAME", 0x6011:
    "PRODUCT_VERSION", 0x6012: "FILE_DESCRIPTION", 0x6013: "FILE_VERSION", 0x6014:
    "ORIGINAL_FILENAME", 0x6015: "INTERNAL_NAME", 0x6016: "LEGAL_COPYRIGHT", 0x6017:
    "16BIT_DESCRIPTION", 0x6018: "APPHELP_DETAILS", 0x6019: "LINK_URL", 0x601A:
    "LINK_TEXT", 0x601B: "APPHELP_TITLE", 0x601C: "APPHELP_CONTACT", 0x601D:
    "SXS_MANIFEST", 0x601E: "DATA_STRING", 0x601F: "MSI_TRANSFORM_FILE", 0x6020:
    "16BIT_MODULE_NAME", 0x6021: "LAYER_DISPLAYNAME", 0x6022: "COMPILER_VERSION",
    0x6023: "ACTION_TYPE", 0x6024: "EXPORT_NAME", 0x6025: "URL", 0x7001: "DATABASE",
    0x7002: "LIBRARY", 0x7003: "INEXCLUD", 0x7004: "SHIM", 0x7005: "PATCH", 0x7006:
    "APP", 0x7007: "EXE", 0x7008: "MATCHING_FILE", 0x7009: "SHIM_REF", 0x700A: "PATCH_REF", 0x700B:
    "LAYER", 0x700C: "FILE", 0x700D: "APPHELP", 0x700E: "LINK", 0x700F: "DATA",
    0x7010: "MSI_TRANSFORM", 0x7011: "MSI_TRANSFORM_REF", 0x7012: "MSI_PACKAGE",
    0x7013: "FLAG", 0x7014: "MSI_CUSTOM_ACTION", 0x7015: "FLAG_REF", 0x7016:
    "ACTION", 0x7017: "LOOKUP", 0x7018: "CONTEXT", 0x7019: "CONTEXT_REF", 0x701A:
    "KDEVICE", 0x701C: "KDRIVER", 0x7020: "SPC", 0x7025: "KSHIM", 0x7026:
    "KSHIM_REF", 0x7801: "STRINGTABLE", 0x7802: "INDEXES", 0x7803: "INDEX", 0x8801:
    "STRINGTABLE_ITEM", 0x9002: "PATCH_BITS", 0x9003: "FILE_BITS", 0x9004: "EXE_ID",
    0x9005: "DATA_BITS", 0x9006: "MSI_PACKAGE_ID", 0x9007: "DATABASE_ID", 0x9008:
    "CONTEXT_PLATFORM_ID", 0x9009: "CONTEXT_BRANCH_ID", 0x9010: "FIX_ID", 0x9011:
    "APP_ID", 0x9801: "INDEX_BITS",
}

SDB_TYPE_NAMES = {
    0x1000: "null", 0x2000: "byte", 0x3000: "word", 0x4000: "dword",
    0x5000: "qword", 0x6000: "stringref", 0x7000: "list", 0x8000: "string",
    0x9000: "binary",
}
SDB_FIXED_SIZES = {0x1000: 0, 0x2000: 1, 0x3000: 2, 0x4000: 4, 0x5000: 8, 0x6000: 4}
SDB_STRINGTABLE = 0x7801
SDB_INDEXES = 0x7802


def is_shim_sdb(header):
    """True if the file starts with a shim database header."""
    return len(header) >= 12 and header[8:12] == b"sdbf"


def sdb_element_name(tag):
    """XML element name for a tag, e.g. 0x7007 -> 'EXE'."""
    name = SDB_TAG_NAMES.get(tag)
    if name is None:
        return "TAG_0x%04X" % tag
    return "_" + name if name[0].isdigit() else name


def sdb_read_string(data, offset, size):
    raw = data[offset:offset + size]
    return raw.decode("utf-16-le", errors="replace").split("\x00", 1)[0]


def filetime_to_iso(value):
    """Windows FILETIME (100ns ticks since 1601) to ISO text, or None."""
    if not value:
        return None
    try:
        moment = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc)
        return (moment + datetime.timedelta(microseconds=value // 10)).isoformat()
    except OverflowError:
        return None


class ShimWriter:
    """Walks the tag tree of a shim database and writes it as nested XML."""

    def __init__(self, data, out, binary_mode, all_tags):
        self.data = data
        self.out = out
        self.binary_mode = binary_mode
        self.all_tags = all_tags
        self.stringtable = None  # offset of the STRINGTABLE tag
        self.count = 0
        self.warnings = 0

    def find_stringtable(self):
        """The string table is a top-level list; locate it before writing."""
        offset = 12
        while offset + 6 <= len(self.data):
            tag = struct.unpack_from("<H", self.data, offset)[0]
            if tag & 0xF000 != 0x7000:
                break
            size = struct.unpack_from("<I", self.data, offset + 2)[0]
            if tag == SDB_STRINGTABLE:
                self.stringtable = offset
                return
            offset += 6 + size + (size & 1)

    def resolve(self, ref):
        """Follow a string reference into the string table."""
        if self.stringtable is None or ref == 0:
            return None
        item = self.stringtable + ref
        if item + 6 > len(self.data):
            return None
        size = struct.unpack_from("<I", self.data, item + 2)[0]
        return sdb_read_string(self.data, item + 6, size)

    def walk(self, offset, end, depth):
        data, out = self.data, self.out
        pad = "  " * depth
        while offset + 2 <= end:
            tag = struct.unpack_from("<H", data, offset)[0]
            kind = tag & 0xF000
            if kind not in SDB_TYPE_NAMES:
                # Single-byte values may be followed by one padding byte.
                offset += 1
                self.warnings += 1
                continue
            name = sdb_element_name(tag)
            offset += 2
            self.count += 1

            if kind in SDB_FIXED_SIZES:
                size = SDB_FIXED_SIZES[kind]
                if offset + size > end:
                    out.write(f"{pad}<error>truncated {name}</error>\n")
                    return
                raw = data[offset:offset + size]
                offset += size
                if kind == 0x1000:
                    out.write(f"{pad}<{name}/>\n")
                elif kind == 0x6000:
                    text = self.resolve(struct.unpack("<I", raw)[0])
                    if text is None:
                        out.write(f"{pad}<{name}/>\n")
                    else:
                        out.write(f"{pad}<{name}>{clean(text)}</{name}>\n")
                else:
                    value = int.from_bytes(raw, "little")
                    extra = f' hex="0x{value:0{size * 2}X}"' if size >= 4 else ""
                    if kind == 0x5000 and "TIME" in name:
                        iso = filetime_to_iso(value)
                        if iso:
                            extra += f' time="{iso}"'
                    out.write(f"{pad}<{name}{extra}>{value}</{name}>\n")
                continue

            if offset + 4 > end:
                out.write(f"{pad}<error>truncated {name}</error>\n")
                return
            size = struct.unpack_from("<I", data, offset)[0]
            offset += 4
            body_end = offset + size
            if body_end > end:
                out.write(f"{pad}<error>{name} runs past its parent</error>\n")
                self.warnings += 1
                body_end = end

            if kind == 0x7000:
                skip = tag in (SDB_STRINGTABLE, SDB_INDEXES) and not self.all_tags
                if not skip:
                    out.write(f"{pad}<{name}>\n")
                    self.walk(offset, body_end, depth + 1)
                    out.write(f"{pad}</{name}>\n")
            elif kind == 0x8000:
                text = sdb_read_string(data, offset, body_end - offset)
                out.write(f"{pad}<{name}>{clean(text)}</{name}>\n")
            else:
                raw = bytes(data[offset:body_end])
                extra = ""
                if len(raw) == 16 and name.endswith("_ID"):
                    extra = f' guid="{uuid.UUID(bytes_le=raw)}"'
                text, enc = format_scalar(raw, self.binary_mode)
                out.write(f'{pad}<{name} encoding="{enc}"{extra}>{text}</{name}>\n')
            offset = body_end + (size & 1)


def convert_shim(src, dst, args):
    """Convert an application compatibility database to XML."""
    data = src.read_bytes()
    major, minor = struct.unpack_from("<II", data, 0)
    with dst.open("w", encoding="utf-8", newline="\n") as out:
        out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        out.write(
            f'<sdb source={attr(src.name)} format="shim" '
            f'version="{major}.{minor}">\n'
        )
        writer = ShimWriter(data, out, args.binary, args.all_tags)
        writer.find_stringtable()
        writer.walk(12, len(data), 1)
        out.write("</sdb>\n")
    note = f" ({writer.warnings} unreadable spots skipped)" if writer.warnings else ""
    print(f"Wrote {writer.count} tags to {dst}{note}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description="Convert Windows .edb and .sdb database files to XML."
    )
    parser.add_argument("input", help="path to the .edb / .sdb / .dat / .dit file")
    parser.add_argument("-o", "--output", help="output XML path (default: <input>.xml)")
    parser.add_argument(
        "-t", "--table", action="append", default=[],
        help="export only this table (repeat for several)",
    )
    parser.add_argument("--list", action="store_true", help="list tables and exit")
    parser.add_argument(
        "--max-rows", type=int, default=None,
        help="export at most this many rows per table",
    )
    parser.add_argument(
        "--binary", choices=("hex", "base64"), default="hex",
        help="how to encode binary columns (default: hex)",
    )
    parser.add_argument(
        "--include-nulls", action="store_true",
        help="write empty columns as <field null=\"true\"/> instead of omitting them",
    )
    parser.add_argument(
        "--skip-system", action="store_true",
        help="skip the internal MSys* catalog tables",
    )
    parser.add_argument(
        "--all-tags", action="store_true",
        help="shim .sdb only: also write the string table and lookup indexes",
    )
    args = parser.parse_args()

    src = Path(args.input)
    if not src.is_file():
        sys.exit(f"File not found: {src}")

    dst = Path(args.output) if args.output else src.with_suffix(".xml")

    with src.open("rb") as fh:
        header = fh.read(12)
    if is_shim_sdb(header):
        if args.list or args.table:
            sys.exit(
                f"{src.name} is an application compatibility database; it has "
                "no tables, so --list and --table do not apply."
            )
        convert_shim(src, dst, args)
        return

    if EseDB is None:
        sys.exit("Missing dependency. Install it with:  pip install dissect.esedb")

    with src.open("rb") as fh:
        try:
            db = EseDB(fh)
            tables = list(db.tables())
        except Exception as exc:
            sys.exit(
                f"Could not read {src.name} as an ESE database or a shim "
                f"database: {exc}\n"
                "If the file was copied from a running system it may be in a "
                "'dirty shutdown' state; repair a COPY first with:\n"
                "  esentutl /r <logbase> /d   (or)   esentutl /p <copy.edb>"
            )

        if args.list:
            for table in tables:
                print(f"{table.name}  ({len(list(table.columns))} columns)")
            return

        if args.table:
            wanted = {name.lower() for name in args.table}
            found = {t.name.lower() for t in tables}
            missing = sorted(wanted - found)
            if missing:
                sys.exit(
                    "Table(s) not found: " + ", ".join(missing)
                    + "\nRun with --list to see the available tables."
                )
            tables = [t for t in tables if t.name.lower() in wanted]

        if args.skip_system:
            tables = [t for t in tables if not t.name.startswith("MSys")]

        total_rows = 0
        with dst.open("w", encoding="utf-8", newline="\n") as out:
            out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            out.write(f"<database source={attr(src.name)}>\n")
            for table in tables:
                rows, _ = export_table(out, table, args)
                total_rows += rows
                print(f"  {table.name}: {rows} rows", file=sys.stderr)
            out.write("</database>\n")

    print(f"Wrote {len(tables)} tables, {total_rows} rows to {dst}", file=sys.stderr)


if __name__ == "__main__":
    main()
