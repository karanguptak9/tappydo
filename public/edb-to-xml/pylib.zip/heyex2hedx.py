#!/usr/bin/env python3
"""Convert Heidelberg HEYEX / Spectralis raw files (.pdb, .edb, .sdb) of one
scan into an HEDX-style XML file (with the ETDRS Thickness Grid) and a PDF
printout of that XML.

    python3 heyex2hedx.py patient.pdb study.edb series.sdb -o scan.xml --pdf scan.pdf

Give it all the files of the scan; the order does not matter. Everything
runs locally.
"""
import argparse
import datetime
import struct
import sys
from pathlib import Path
from xml.sax.saxutils import escape

import edb2xml as E

MM_PER_DEGREE = E.MM_PER_DEGREE


def read_all(paths):
    """Return (entries with decoded fields, thickness grids)."""
    items, grids = [], []
    for path in paths:
        size = Path(path).stat().st_size
        with open(path, "rb") as fh:
            if not E.is_heyex(fh.read(4)):
                raise ValueError(f"{Path(path).name} is not a Heidelberg file.")
            fh.seek(0)
            entries = list(E.heyex_directory(fh, size))
            for e in entries:
                kind = e["type"]
                if kind == E.HEYEX_IMAGE:
                    # only the picture's header is needed, not its pixels
                    try:
                        fh.seek(e["start"] + 60)
                        _, subtype, _, height, width = struct.unpack("<5I", fh.read(20))
                        what = {E.HEYEX_IMG_FUNDUS: "fundus", E.HEYEX_IMG_BSCAN: "bscan"}.get(subtype, "unknown")
                        items.append((e, {"kind": what, "width": width, "height": height}, None))
                    except Exception:
                        pass
                    continue
                if kind in (5, 9, 11, 13, 39, 58, 10004, 9005, 9006, 9008, 9001):
                    try:
                        data = E.heyex_read(fh, e, size)
                        items.append((e, dict(E.heyex_decode(kind, data) or []), bytes(data)))
                    except Exception:
                        pass
            try:
                grids += E.heyex_thickness_grids(fh, entries, size)
            except Exception:
                pass
    return items, grids


def ole_date(days):
    return datetime.date(1899, 12, 30) + datetime.timedelta(days=int(days))


def filetime(ticks):
    return datetime.datetime(1601, 1, 1) + datetime.timedelta(microseconds=ticks / 10)


def _switch_day(year, st):
    """Date/time of a Windows time-zone switch (SYSTEMTIME 'nth weekday' rule)."""
    _, month, dow, week, hour = st[0], st[1], st[2], st[3], st[4]
    first = datetime.date(year, month, 1)
    shift = (dow - (first.weekday() + 1) % 7) % 7      # Windows: Sunday = 0
    day = 1 + shift + 7 * (week - 1)
    while True:
        try:
            return datetime.datetime(year, month, day, hour)
        except ValueError:
            day -= 7                                   # week 5 means "last"


def utc_bias(raw39, when):
    """Minutes to add to UTC to get the local time of the exam, from the
    Windows time-zone block stored with the acquisition settings."""
    off = 180
    if not raw39 or len(raw39) < off + 172:
        return None
    try:
        bias = struct.unpack_from("<i", raw39, off)[0]
        name = raw39[off + 4:off + 68].decode("utf-16-le").rstrip("\0")
        std = struct.unpack_from("<8H", raw39, off + 68)
        std_bias = struct.unpack_from("<i", raw39, off + 84)[0]
        dst = struct.unpack_from("<8H", raw39, off + 152)
        dst_bias = struct.unpack_from("<i", raw39, off + 168)[0]
    except (struct.error, UnicodeDecodeError):
        return None
    if not name or not name.isprintable() or abs(bias) > 900:
        return None
    extra = std_bias
    if when and std[1] and dst[1]:
        try:
            start, end = _switch_day(when.year, dst), _switch_day(when.year, std)
            in_dst = (start <= when < end) if start < end else not (end <= when < start)
            extra = dst_bias if in_dst else std_bias
        except Exception:
            pass
    return -(bias + extra)


def resolution(pixels, degrees):
    """Spectralis high-speed mode has about 25.6 pixels per degree, high
    resolution twice that."""
    if not pixels or not degrees:
        return None
    return "HIRES" if pixels / degrees > 38 else "LORES"


class Out:
    def __init__(self):
        self.lines = []

    def tag(self, name, value=None):
        if value is None or value == "":
            self.lines.append(f"<{name}/>")
        else:
            self.lines.append(f"<{name}>{escape(str(value))}</{name}>")

    def open(self, name):
        self.lines.append(f"<{name}>")

    def close(self, name):
        self.lines.append(f"</{name}>")

    def date(self, name, d):
        self.open(name); self.open("Date")
        self.tag("Year", d.year); self.tag("Month", d.month); self.tag("Day", d.day)
        self.close("Date"); self.close(name)


def series_keys(items):
    """All (patient, study, series) triples found in the files."""
    keys = []
    for e, _, _ in items:
        if e["series"] >= 0:
            key = (e["patient"], e["study"], e["series"])
            if key not in keys:
                keys.append(key)
    return sorted(keys)


def build_series(all_items, all_grids, key):
    """HEDX text for one series. Returns (xml, notes)."""
    patient, study, series = key
    items = [it for it in all_items
             if it[0]["patient"] == patient and it[0]["study"] in (study, -1)
             and it[0]["series"] in (series, -1)]
    grids = [g for g in all_grids if (g["patient"], g["study"], g["series"]) == key]
    notes = []

    def first(kind):
        best = None
        for e, f, raw in items:
            if e["type"] == kind:
                if e["series"] == series:
                    return e, f, raw
                best = best or (e, f, raw)
        return best or (None, {}, None)

    pe, pf, _ = first(9)
    patient_id = patient
    study_ids, series_ids = [study], [series]

    se, sf, sraw = first(58)
    study_date = operator = None
    if sraw and len(sraw) >= 20:
        try:
            study_date = ole_date(struct.unpack_from("<d", sraw, 6)[0])
            operator = E.heyex_text(sraw[16:])
        except Exception:
            notes.append("study date/operator not decoded")

    eye = first(11)[1].get("laterality") or first(5)[1].get("laterality")
    side = {"OD": "R", "OS": "L"}.get(eye)

    metas = sorted((f for e, f, _ in items if e["type"] == 10004), key=lambda f: f.get("bscan_index", 0))
    fundus = [f for e, f, _ in items if e["type"] == E.HEYEX_IMAGE and f.get("kind") == "fundus"]

    o = Out()
    o.open("HEDX"); o.open("BODY")
    o.tag("ExportType", "Data")
    o.open("Patient")
    o.tag("ID", patient_id)
    o.tag("PatientID", pf.get("patient_id"))
    o.tag("LastName", pf.get("surname"))
    o.tag("FirstNames", pf.get("firstname"))
    if pf.get("birthdate"):
        o.date("Birthdate", datetime.date.fromisoformat(pf["birthdate"]))
    o.tag("Sex", pf.get("sex"))
    o.open("Study")
    o.tag("ID", study_ids[0] if study_ids else None)
    if study_date:
        o.date("StudyDate", study_date)
    o.tag("Operator", operator)
    o.tag("ReferringPhysician")
    o.open("Series")
    o.tag("ID", series_ids[0] if series_ids else None)
    structure = first(9005)[1].get("text")
    if structure:
        o.tag("ExaminedStructure", structure[0])
    if metas:
        o.tag("Modality", "OCT")
        o.tag("Type", "Volume" if len(metas) > 1 else "Single")
    o.tag("Laterality", side)
    raw39 = first(39)[2]
    raw5 = first(5)[2]
    app_text = " ".join(str(x) for x in (first(13)[1].get("text") or []))
    o.open("GeneralEquipment")
    o.tag("Manufacturer", "Heidelberg Engineering")
    if "Spectralis" in app_text:
        o.tag("ManufacturerModelName", "Spectralis")
    if raw39 and len(raw39) >= 144 and max(raw39[140:144]) < 100 and raw39[140]:
        o.open("AQMVersion")
        o.tag("Name", "Spectralis Acquisition Module")
        o.tag("Version", ".".join(str(b) for b in raw39[140:144]))
        o.close("AQMVersion")
    o.close("GeneralEquipment")

    if metas:
        m0 = metas[0]
        ys = [m["start_y"] for m in metas]
        o.open("OCTFieldSize")
        o.tag("Width", f'{abs(m0["end_x"] - m0["start_x"]):.1f}')
        o.tag("Height", f"{max(ys) - min(ys):.1f}")
        o.close("OCTFieldSize")

    for g in grids[:1]:
        loc_w = struct.unpack_from("<H", raw5, 14)[0] if raw5 and len(raw5) >= 16 else (
            fundus[0].get("width") if fundus else None)
        centre_px = (loc_w // 2) if loc_w else 384
        o.open("ThicknessGrid")
        o.tag("Type", 3)
        o.tag("Name", "1, 3, 6 mm ETDRS")
        o.tag("Diameter1", "1.00"); o.tag("Diameter2", "3.00"); o.tag("Diameter3", "6.00")
        o.tag("IsDefaultPos", "true")
        o.open("CenterPos"); o.open("Coord")
        o.tag("X", centre_px); o.tag("Y", centre_px)
        o.close("Coord"); o.close("CenterPos")
        if g["center"] is not None:
            o.tag("CentralThickness", f'{g["center"]:.3f}')
        o.tag("MinCentralThickness", f'{g["min"]:.3f}')
        o.tag("MaxCentralThickness", f'{g["max"]:.3f}')
        o.tag("TotalVolume", f'{g["volume"]:.3f}')
        for name, avg, vol, valid in g["zones"]:
            o.open("Zone")
            o.tag("Name", name)
            o.tag("AvgThickness", f"{avg:.3f}")
            o.tag("Volume", f"{vol:.3f}")
            o.tag("ValidPixelPercentage", f"{valid:.3f}")
            o.close("Zone")
        o.close("ThicknessGrid")
    if not metas:
        notes.append("No scan details found. They are in the .edb file of the study "
                     "(B-scan positions, times, layer lines). The .sdb only holds the pictures.")
    elif not grids:
        notes.append("Thickness grid not computed: no ILM/BM layer lines found in the files given.")
    if not pf:
        notes.append("No patient details found. They are in the .pdb file.")

    def time_block(t):
        o.open("AcquisitionTime"); o.open("Time")
        o.tag("Hour", t.hour); o.tag("Minute", t.minute)
        o.tag("Second", f"{t.second + t.microsecond / 1e6:.3f}")
        bias = utc_bias(raw39, t)
        if bias is not None:
            o.tag("UTCBias", bias)
        o.close("Time"); o.close("AcquisitionTime")

    # the localizer (fundus) picture: described by record 5, pixels in the .sdb
    loc = None
    if raw5 and len(raw5) >= 26:
        ticks, h, w = struct.unpack_from("<QHH", raw5, 4)
        angle = struct.unpack_from("<H", raw5, 24)[0]
        if 0 < w <= 8192 and 0 < h <= 8192:
            loc = {"width": w, "height": h, "angle": angle if 0 < angle <= 120 else None}
            try:
                loc["time"] = filetime(ticks)
            except (OverflowError, ValueError):
                pass
    elif fundus:
        loc = {"width": fundus[0].get("width"), "height": fundus[0].get("height")}

    # without the .edb only the pictures themselves are known
    bare = [] if metas else [f for e, f, _ in sorted(
        (it for it in items if it[0]["type"] == E.HEYEX_IMAGE and it[1].get("kind") == "bscan"),
        key=lambda it: it[0]["slice"])]
    o.tag("NumImages", len(metas) + len(bare) + (1 if loc else 0))
    centre = (loc["angle"] * MM_PER_DEGREE / 2) if loc and loc.get("angle") else 4.4405
    n = 0
    if loc:
        o.open("Image"); o.tag("ID", 0); o.tag("ImageNumber", 0); o.tag("Laterality", side)
        if loc.get("time"):
            time_block(loc["time"])
        o.open("ImageType"); o.tag("Type", "LOCALIZER"); o.close("ImageType")
        o.open("OphthalmicAcquisitionContext")
        o.tag("Width", loc["width"]); o.tag("Height", loc["height"])
        if loc.get("angle"):
            o.tag("ScaleX", f'{loc["angle"] * MM_PER_DEGREE / loc["width"]:.4f}')
            o.tag("ScaleY", f'{loc["angle"] * MM_PER_DEGREE / loc["width"]:.4f}')
            o.tag("Angle", loc["angle"])
            o.tag("Resolution", resolution(loc["width"], loc["angle"]))
        if raw39 and len(raw39) >= 120:
            gain = struct.unpack_from("<I", raw39, 116)[0]
            if 0 < gain <= 200:
                o.tag("SensorGain", gain)
        o.close("OphthalmicAcquisitionContext")
        o.close("Image")
        n = 1
    for i, f in enumerate(bare):
        o.open("Image"); o.tag("ID", n + i); o.tag("ImageNumber", n + i); o.tag("Laterality", side)
        o.open("ImageType"); o.tag("Type", "OCT"); o.close("ImageType")
        o.open("OphthalmicAcquisitionContext")
        o.tag("Width", f.get("width")); o.tag("Height", f.get("height"))
        o.close("OphthalmicAcquisitionContext")
        o.close("Image")
    for i, m in enumerate(metas):
        o.open("Image"); o.tag("ID", n + i); o.tag("ImageNumber", n + i); o.tag("Laterality", side)
        ts = m.get("acquisition_time")
        if isinstance(ts, str):
            time_block(datetime.datetime.fromisoformat(ts).replace(tzinfo=None))
        o.open("ImageType"); o.tag("Type", "OCT"); o.close("ImageType")
        o.open("OphthalmicAcquisitionContext")
        o.tag("Width", m.get("size_x")); o.tag("Height", m.get("size_y"))
        degrees = abs(m["end_x"] - m["start_x"]) or abs(m["end_y"] - m["start_y"])
        o.tag("ScaleX", f'{degrees * MM_PER_DEGREE / m["size_x"]:.4f}')
        o.tag("ScaleY", f'{m["scale_y"]:.4f}')
        o.tag("Resolution", resolution(m["size_x"], degrees))
        if m.get("art_mode"):
            o.tag("NumAve", m["art_mode"])
        if m.get("quality_ui") is not None:
            o.tag("ImageQuality", int(round(m["quality_ui"])))
        for label, x, y in (("Start", m["start_x"], m["start_y"]), ("End", m["end_x"], m["end_y"])):
            o.open(label); o.open("Coord")
            o.tag("X", f"{centre + x * MM_PER_DEGREE:.3f}")
            o.tag("Y", f"{centre + y * MM_PER_DEGREE:.3f}")
            o.close("Coord"); o.close(label)
        o.close("OphthalmicAcquisitionContext")
        o.close("Image")
    o.close("Series"); o.close("Study"); o.close("Patient"); o.close("BODY"); o.close("HEDX")
    return "\n".join(o.lines) + "\n", notes


def build_all(paths):
    """One report per series found: list of dicts (series, name, xml, notes)."""
    items, grids = read_all(paths)
    reports = []
    for key in series_keys(items):
        xml, notes = build_series(items, grids, key)
        reports.append({"series": key[2], "name": f"{key[2]:08d}", "xml": xml, "notes": notes,
                        "images": xml.count("<Image>"), "grid": "<ThicknessGrid>" in xml})
    return reports


def pdf_bytes(text, size=9, per_page=62):
    """A plain monospaced PDF of the text (no external libraries)."""
    lines = text.splitlines()
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[]]
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", None,
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"]
    kids = []
    for chunk in pages:
        stream = ["BT", f"/F1 {size} Tf", f"{size + 2} TL", "36 756 Td"]
        for ln in chunk:
            safe = ln.encode("latin-1", "replace").decode("latin-1")
            safe = safe.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            stream.append(f"({safe}) '")
        stream.append("ET")
        body = "\n".join(stream).encode("latin-1")
        objs.append(b"<< /Length %d >>\nstream\n" % len(body) + body + b"\nendstream")
        content = len(objs)
        objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
                    f"/Resources << /Font << /F1 3 0 R >> >> /Contents {content} 0 R >>".encode())
        kids.append(len(objs))
    objs[1] = (f"<< /Type /Pages /Count {len(kids)} /Kids [" +
               " ".join(f"{k} 0 R" for k in kids) + "] >>").encode()
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help=".pdb, .edb and .sdb files (one scan, or a whole export)")
    ap.add_argument("-d", "--outdir", help="folder for the results (default: folder of the first file)")
    ap.add_argument("-o", "--output", help="XML file name, when the files hold a single series")
    ap.add_argument("--pdf", help="PDF file name, when the files hold a single series")
    args = ap.parse_args()
    reports = build_all(args.files)
    if not reports:
        sys.exit("No scan series found in these files.")
    outdir = Path(args.outdir) if args.outdir else Path(args.files[0]).parent
    outdir.mkdir(parents=True, exist_ok=True)
    for r in reports:
        single = len(reports) == 1
        xml_path = Path(args.output) if (single and args.output) else outdir / (r["name"] + ".xml")
        pdf_path = Path(args.pdf) if (single and args.pdf) else xml_path.with_suffix(".pdf")
        xml_path.write_text(r["xml"], encoding="utf-8")
        pdf_path.write_bytes(pdf_bytes(r["xml"]))
        grid = "with Thickness Grid" if r["grid"] else "no Thickness Grid"
        print(f"Series {r['series']}: {r['images']} images, {grid} -> {xml_path.name}, {pdf_path.name}",
              file=sys.stderr)
        for n in r["notes"]:
            print("  Note:", n, file=sys.stderr)


if __name__ == "__main__":
    main()
