#!/usr/bin/env python3
"""Convert Heidelberg HEYEX / Spectralis raw files (.pdb, .edb, .sdb) of one
scan into an HEDX-style XML file (with the ETDRS Thickness Grid) and a PDF
printout of that XML.

    python3 heyex2hedx.py patient.pdb study.edb series.sdb -o scan.xml --pdf scan.pdf

Give it all the files of the scan; the order does not matter. Everything
runs locally.
"""
import argparse
import datetime
import struct
import sys
from pathlib import Path
from xml.sax.saxutils import escape

import edb2xml as E

MM_PER_DEGREE = 0.29605   # 5.921 mm per 20 degrees


def read_all(paths):
    """Return (entries with decoded fields, thickness grids)."""
    items, grids = [], []
    for path in paths:
        size = Path(path).stat().st_size
        with open(path, "rb") as fh:
            if not E.is_heyex(fh.read(4)):
                sys.exit(f"{Path(path).name} is not a Heidelberg file.")
            fh.seek(0)
            entries = list(E.heyex_directory(fh, size))
            for e in entries:
                kind = e["type"]
                if kind == E.HEYEX_IMAGE:
                    try:
                        fields = dict(E.heyex_image(E.heyex_read(fh, e, size))[0])
                        items.append((e, fields, None))
                    except Exception:
                        pass
                    continue
                if kind in (9, 11, 58, 10004, 9005, 9006, 9008, 9001):
                    try:
                        data = E.heyex_read(fh, e, size)
                        items.append((e, dict(E.heyex_decode(kind, data) or []), bytes(data)))
                    except Exception:
                        pass
            try:
                grids += E.heyex_thickness_grids(fh, entries, size)
            except Exception:
                pass
    return items, grids


def ole_date(days):
    return datetime.date(1899, 12, 30) + datetime.timedelta(days=int(days))


class Out:
    def __init__(self):
        self.lines = []

    def tag(self, name, value=None):
        if value is None or value == "":
            self.lines.append(f"<{name}/>")
        else:
            self.lines.append(f"<{name}>{escape(str(value))}</{name}>")

    def open(self, name):
        self.lines.append(f"<{name}>")

    def close(self, name):
        self.lines.append(f"</{name}>")

    def date(self, name, d):
        self.open(name); self.open("Date")
        self.tag("Year", d.year); self.tag("Month", d.month); self.tag("Day", d.day)
        self.close("Date"); self.close(name)


def build(paths):
    items, grids = read_all(paths)
    notes = []

    def first(kind, key=None):
        for e, f, raw in items:
            if e["type"] == kind:
                return e, f, raw
        return None, {}, None

    pe, pf, _ = first(9)
    patient_id = pe["patient"] if pe else None
    if patient_id is None:
        ids = [e["patient"] for e, _, _ in items if e["patient"] >= 0]
        patient_id = ids[0] if ids else None
    study_ids = sorted({e["study"] for e, _, _ in items if e["study"] >= 0})
    series_ids = sorted({e["series"] for e, _, _ in items if e["series"] >= 0})

    se, sf, sraw = first(58)
    study_date = operator = None
    if sraw and len(sraw) >= 20:
        try:
            study_date = ole_date(struct.unpack_from("<d", sraw, 6)[0])
            operator = E.heyex_text(sraw[16:])
        except Exception:
            notes.append("study date/operator not decoded")

    eye = next((f.get("laterality") for e, f, _ in items if e["type"] == 11 and f.get("laterality")), None)
    side = {"OD": "R", "OS": "L"}.get(eye)

    metas = sorted((f for e, f, _ in items if e["type"] == 10004), key=lambda f: f.get("bscan_index", 0))
    fundus = [f for e, f, _ in items if e["type"] == E.HEYEX_IMAGE and f.get("kind") == "fundus"]

    o = Out()
    o.open("HEDX"); o.open("BODY")
    o.tag("ExportType", "Data")
    o.open("Patient")
    o.tag("ID", patient_id)
    o.tag("PatientID", pf.get("patient_id"))
    o.tag("LastName", pf.get("surname"))
    o.tag("FirstNames", pf.get("firstname"))
    if pf.get("birthdate"):
        o.date("Birthdate", datetime.date.fromisoformat(pf["birthdate"]))
    o.tag("Sex", pf.get("sex"))
    o.open("Study")
    o.tag("ID", study_ids[0] if study_ids else None)
    if study_date:
        o.date("StudyDate", study_date)
    o.tag("Operator", operator)
    o.tag("ReferringPhysician")
    o.open("Series")
    o.tag("ID", series_ids[0] if series_ids else None)
    structure = first(9005)[1].get("text")
    o.tag("ExaminedStructure", structure[0] if structure else "Retina")
    o.tag("Modality", "OCT")
    o.tag("Type", "Volume" if len(metas) > 1 else "Single")
    o.tag("Laterality", side)
    o.open("GeneralEquipment")
    o.tag("Manufacturer", "Heidelberg Engineering")
    o.tag("ManufacturerModelName", "Spectralis")
    o.close("GeneralEquipment")

    if metas:
        m0 = metas[0]
        ys = [m["start_y"] for m in metas]
        o.open("OCTFieldSize")
        o.tag("Width", f'{abs(m0["end_x"] - m0["start_x"]):.1f}')
        o.tag("Height", f"{max(ys) - min(ys):.1f}")
        o.close("OCTFieldSize")

    for g in grids[:1]:
        centre_px = (fundus[0]["width"] // 2) if fundus and "width" in fundus[0] else 384
        o.open("ThicknessGrid")
        o.tag("Type", 3)
        o.tag("Name", "1, 3, 6 mm ETDRS")
        o.tag("Diameter1", "1.00"); o.tag("Diameter2", "3.00"); o.tag("Diameter3", "6.00")
        o.tag("IsDefaultPos", "true")
        o.open("CenterPos"); o.open("Coord")
        o.tag("X", centre_px); o.tag("Y", centre_px)
        o.close("Coord"); o.close("CenterPos")
        if g["center"] is not None:
            o.tag("CentralThickness", f'{g["center"]:.3f}')
        o.tag("MinCentralThickness", f'{g["min"]:.3f}')
        o.tag("MaxCentralThickness", f'{g["max"]:.3f}')
        o.tag("TotalVolume", f'{g["volume"]:.3f}')
        for name, avg, vol, valid in g["zones"]:
            o.open("Zone")
            o.tag("Name", name)
            o.tag("AvgThickness", f"{avg:.3f}")
            o.tag("Volume", f"{vol:.3f}")
            o.tag("ValidPixelPercentage", f"{valid:.3f}")
            o.close("Zone")
        o.close("ThicknessGrid")
    if not grids:
        notes.append("thickness grid not computed (needs the .edb with the layer lines)")

    o.tag("NumImages", len(metas) + (1 if fundus else 0))
    centre = 4.4405
    n = 0
    if fundus:
        f = fundus[0]
        o.open("Image"); o.tag("ID", 0); o.tag("ImageNumber", 0); o.tag("Laterality", side)
        o.open("ImageType"); o.tag("Type", "LOCALIZER"); o.tag("LightSource", "IR"); o.close("ImageType")
        o.open("OphthalmicAcquisitionContext")
        o.tag("Width", f.get("width")); o.tag("Height", f.get("height"))
        o.close("OphthalmicAcquisitionContext")
        o.close("Image")
        n = 1
    for i, m in enumerate(metas):
        o.open("Image"); o.tag("ID", n + i); o.tag("ImageNumber", n + i); o.tag("Laterality", side)
        ts = m.get("acquisition_time")
        if ts:
            t = datetime.datetime.fromisoformat(str(ts))
            o.open("AcquisitionTime"); o.open("Time")
            o.tag("Hour", t.hour); o.tag("Minute", t.minute)
            o.tag("Second", f"{t.second + t.microsecond / 1e6:.3f}")
            o.close("Time"); o.close("AcquisitionTime")
        o.open("ImageType"); o.tag("Type", "OCT"); o.close("ImageType")
        o.open("OphthalmicAcquisitionContext")
        o.tag("Width", m.get("size_x")); o.tag("Height", m.get("size_y"))
        width_mm = abs(m["end_x"] - m["start_x"]) * MM_PER_DEGREE
        o.tag("ScaleX", f'{width_mm / m["size_x"]:.4f}')
        o.tag("ScaleY", f'{m["scale_y"]:.4f}')
        if m.get("quality_ui") is not None:
            o.tag("ImageQuality", int(round(m["quality_ui"])))
        for label, x, y in (("Start", m["start_x"], m["start_y"]), ("End", m["end_x"], m["end_y"])):
            o.open(label); o.open("Coord")
            o.tag("X", f"{centre + x * MM_PER_DEGREE:.3f}")
            o.tag("Y", f"{centre + y * MM_PER_DEGREE:.3f}")
            o.close("Coord"); o.close(label)
        o.close("OphthalmicAcquisitionContext")
        o.close("Image")
    o.close("Series"); o.close("Study"); o.close("Patient"); o.close("BODY"); o.close("HEDX")
    return "\n".join(o.lines) + "\n", notes


def pdf_bytes(text, size=9, per_page=62):
    """A plain monospaced PDF of the text (no external libraries)."""
    lines = text.splitlines()
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[]]
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", None,
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"]
    kids = []
    for chunk in pages:
        stream = ["BT", f"/F1 {size} Tf", f"{size + 2} TL", "36 756 Td"]
        for ln in chunk:
            safe = ln.encode("latin-1", "replace").decode("latin-1")
            safe = safe.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            stream.append(f"({safe}) '")
        stream.append("ET")
        body = "\n".join(stream).encode("latin-1")
        objs.append(b"<< /Length %d >>\nstream\n" % len(body) + body + b"\nendstream")
        content = len(objs)
        objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
                    f"/Resources << /Font << /F1 3 0 R >> >> /Contents {content} 0 R >>".encode())
        kids.append(len(objs))
    objs[1] = (f"<< /Type /Pages /Count {len(kids)} /Kids [" +
               " ".join(f"{k} 0 R" for k in kids) + "] >>").encode()
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help=".pdb, .edb and .sdb files of one scan")
    ap.add_argument("-o", "--output", help="XML file to write (default: next to the first file)")
    ap.add_argument("--pdf", help="PDF file to write (default: same name as the XML)")
    args = ap.parse_args()
    xml_path = Path(args.output) if args.output else Path(args.files[0]).with_suffix(".hedx.xml")
    pdf_path = Path(args.pdf) if args.pdf else xml_path.with_suffix(".pdf")
    xml, notes = build(args.files)
    xml_path.write_text(xml, encoding="utf-8")
    pdf_path.write_bytes(pdf_bytes(xml))
    print(f"Wrote {xml_path} and {pdf_path}", file=sys.stderr)
    for n in notes:
        print("Note:", n, file=sys.stderr)


if __name__ == "__main__":
    main()
